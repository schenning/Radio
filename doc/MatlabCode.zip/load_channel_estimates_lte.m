function [H, gps_data, NFrames, minestimates] = load_channel_estimates_lte(filename, time_flag, NFrames_max, decimation, is_eNb, version)
%
% EMOS Single User Import Filter
%
% [H, gps_data, NFrames, minestimates] =
%       load_channel_estimates_lte(filename, time_flag, NFrames_max, decimation, is_eNb, version)
%
% Parameters:
% filename          - filename(s) of the EMOS data file
% time_flag   (opt) - if set to 1, channel estimates are returned in the
%                     time domain (default = frequency domain) 
% NFrames_max (opt) - Maximum number of estimates (default = read all file contents)
% decimation  (opt) - read every 'decimation' frame (default = 1)
% is_eNb      (opt) - if set to 1, data originates from an eNb (default = data originates from UE)
% version     (opt) - for backward compatibility (see details below, default = latest version) 
%
% Returns:
% H                 - 4D array containing channel data in time or frequency
%                     domain (depending on the time_flag). The dimensions of the
%                     array are subc x pilots x links x NFrames for time_flag==0
%                     and taps x pilots x links x NFrames for time_flag==1       
% estimates         - A structure array containing timestamp, etc
% gps_data          - A structure array containing gps data
% NFrames           - the number of read estimates

% Author: Florian Kaltenberger, Imran Latif
% Copyright: Eurecom Sophia Antipolis

% Version History
%   Date      Version   Comment
%   20100317  0.1       Created based on load_estimates

if nargin < 6
    version = Inf;
end
if nargin < 5
    is_eNb = 0;
end
if nargin < 4
    decimation = 1;
end
if nargin < 3
    NFrames_max = Inf;
end
if nargin < 2
    time_flag = 0;
end

% NTx = 2;
% NRx = 2;
% NFreq = 512;
% NZFreq = 300;

% Logfile structure:
%  - 100 entries of type fifo_dump_emos (defined in phy_procedures_emos.h)
%  - 1 entry of type gps_fix_t defined in gps.h

if exist('../../IMPORT_FILTER/a.out','file')
    [dummy,result] = system('../../IMPORT_FILTER/a.out');
    eval(result);
else
    warning('File dump_size.c has to be compiled to enable error checking of sizes');
    %PHY_measurements_size = 1120;
    %UCI_data_t_size = 49;
    %DCI_alloc_t_size = 16;
    %eNb_UE_stats_size = 20;
    %fifo_dump_emos_UE_size = 33492;
    %fifo_dump_emos_eNb_size = 36980;
    %gps_fix_t_size = 108;
end

struct_template;

% if (version < 1)
%     fifo_dump_emos_struct_eNb = fifo_dump_emos_struct_eNb_old;
%     fifo_dump_emos_struct_eNb_a = fifo_dump_emos_struct_eNb_old_a;
% end

gps_fix_t_size = gps_data_struct_a.size;
fifo_dump_emos_UE_size = fifo_dump_emos_struct_UE_a.size;
fifo_dump_emos_eNb_size = fifo_dump_emos_struct_eNb_a.size;


NO_ESTIMATES_DISK = 100;
if (is_eNb)
    CHANNEL_BUFFER_SIZE = NO_ESTIMATES_DISK * fifo_dump_emos_eNb_size + gps_fix_t_size;
else
    CHANNEL_BUFFER_SIZE = NO_ESTIMATES_DISK * fifo_dump_emos_UE_size + gps_fix_t_size;
end

if (mod(NO_ESTIMATES_DISK,decimation) ~= 0)
    error('Decimation must be a divisor of %d',NO_ESTIMATES_DISK);
end

% Estimate the size of the file for a pre-allocation of memory
if ~iscell(filename)
    filename = {filename};
end
NFiles = length(filename);
NFrames_file = zeros(1,NFiles);
for n=1:NFiles
    if ~exist(filename{n},'file')
        error('File does not exist!')
    end
    info_file = dir(filename{n});
    NFrames_file(n) = floor(info_file.bytes/CHANNEL_BUFFER_SIZE)*NO_ESTIMATES_DISK;
    if (mod(info_file.bytes,CHANNEL_BUFFER_SIZE) ~= 0)
        warning('File size not a multiple of buffer size. File might be corrupt or is_eNb flag is wrong.');
    end
end
NFrames = min(sum(NFrames_file), NFrames_max);

% if (is_eNb)
%     estimates = repmat(fifo_dump_emos_struct_eNb,1,floor(NFrames/decimation));
% else
%     estimates = repmat(fifo_dump_emos_struct_UE,1,floor(NFrames/decimation));
% end

if (is_eNb)
    %estimates = repmat(fifo_dump_emos_struct_eNb,1,100);
    
    minestimates = repmat(min_estimates_struct_eNb, 1,NFrames);
else
    %estimates = repmat(fifo_dump_emos_struct_UE,1,100);
    
    if (time_flag==0)
        H_fq = zeros(50,8,4,NFrames); %subc x pilots x links x NFrames
    else
        H_t  = zeros(80,8,4,NFrames);
    end

    minestimates = repmat(min_estimates_struct, 1,NFrames);
    
end
gps_data = repmat(gps_data_struct,1,NFrames/100);

k = 1;
l = 1;
for n=1:NFiles
    fid = fopen(filename{n},'r');
    
    while (~feof(fid) && (k <= min(sum(NFrames_file(1:n)),NFrames_max)))
        
        if (is_eNb)
            estimates_tmp = binread(fid,fifo_dump_emos_struct_eNb,1,4,'l');
            
            minestimates(k).mcs = get_mcs(estimates_tmp.dci_alloc(10,1).dci_pdu,'format0');
            minestimates(k).tbs = get_tbs(minestimates(k).mcs,25);
            minestimates(k).rx_rssi_dBm = estimates_tmp.phy_measurements_eNb(1).rx_rssi_dBm(1);
            minestimates(k).frame_tx = estimates_tmp.frame_tx;
            minestimates(k).timestamp = estimates_tmp.timestamp;
            if (version<1)
                minestimates(k).UE_mode = estimates_tmp.eNb_UE_stats(3,1).UE_mode;
            else
                minestimates(k).UE_mode = estimates_tmp.eNb_UE_stats(1,1).UE_mode;
            end
            minestimates(k).phy_measurements = estimates_tmp.phy_measurements_eNb(1);
            minestimates(k).ulsch_errors = estimates_tmp.ulsch_errors;
            minestimates(k).mimo_mode = estimates_tmp.mimo_mode;
            minestimates(k).eNb_id = estimates_tmp.eNb_UE_stats.sector;
            
        else
            estimates_tmp = binread(fid,fifo_dump_emos_struct_UE,1,4,'l');
            
            minestimates(k).mcs = get_mcs(estimates_tmp.dci_alloc(7,1).dci_pdu);
            minestimates(k).tbs = get_tbs(minestimates(k).mcs,25);
            minestimates(k).rx_rssi_dBm = estimates_tmp.phy_measurements(1).rx_rssi_dBm(1);
            minestimates(k).frame_tx = estimates_tmp.frame_tx;
            minestimates(k).frame_rx = estimates_tmp.frame_rx;
            minestimates(k).pbch_fer = estimates_tmp.pbch_fer(1);
            minestimates(k).timestamp = estimates_tmp.timestamp;
            minestimates(k).UE_mode = estimates_tmp.UE_mode;
            minestimates(k).phy_measurements = estimates_tmp.phy_measurements(1);
            minestimates(k).dlsch_fer = estimates_tmp.dlsch_fer;
            minestimates(k).dlsch_errors = estimates_tmp.dlsch_errors;
            minestimates(k).mimo_mode = estimates_tmp.mimo_mode;
            minestimates(k).eNb_id = estimates_tmp.eNb_id;
            minestimates(k).rx_total_gain_dB = estimates_tmp.rx_total_gain_dB;
            
            
            % Channel
            H = reshape(typecast(estimates_tmp.channel(:),'int16'),[],4,3);
            Hc = double(H(1:2:end,:,:))+1j*double(H(2:2:end,:,:));
            Hs = squeeze(10*log10(sum(sum(abs(Hc).^2,1),2)));
            [dummy, ind] = max(Hs);
            Hr = reshape(Hc(:,:,ind),50,8,4);
            
            if (time_flag==0)
                H_fq(:,:,:,k) = Hr;
            else
        
            for i=1:8
                for j=1:4
                    if mod(i,2)==0
                        tmp = ifft(interp1(1:6:300,Hr(:,i,j),1:1:300,'linear','extrap'),512);
                    else
                        tmp = ifft(interp1(4:6:300,Hr(:,i,j),1:1:300,'linear','extrap'),512);
                    end
                    H_t(:,i,j,k) = tmp(1:80);
                end
            end
            end
        end
        
        
        %read GPS data and estimates every second
        if ((mod(k,NO_ESTIMATES_DISK)==0) && ~feof(fid))
            gps_data(l) = binread(fid,gps_data_struct,1,4,'l');
            l=l+1;
        end
        k=k+1;
    end
    
    fclose(fid);
end

if (time_flag==0)
    H=H_fq;
else
    H=H_t;
end









