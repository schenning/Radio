%% load data
if isunix
    %filename = '/extras/kaltenbe/CNES/MUMIMO_data/UE1/data_term3_idx65_20100720T153407.EMOS';
    filename = '/extras/kaltenbe/CNES/MUMIMO_data/UE2/data_term3_idx06_20100721T093647.EMOS';
    %filename = '/home/kaltenbe/EMOS/data_term3_idx06_20100721T093647.EMOS';
else
    %filename = '\\extras\kaltenbe\CNES\MUMIMO_data\UE1\data_term3_idx65_20100720T153407.EMOS';
    filename = '\\extras\kaltenbe\CNES\MUMIMO_data\UE2\data_term3_idx06_20100721T093647.EMOS';
    %filename = 'E:\Tpdata\Tp_radio\data_term3_idx06_20100721T093647.EMOS';
end    
[H, gps_data, NFrames, minestimates] = load_channel_estimates_lte(filename,0,10000);

%% extract some metadata
UE_mode     = double([minestimates.UE_mode]); % if UE_mode>1, the UE is synchronized. we should discard all other data 
rx_rssi_dBm = double([minestimates.rx_rssi_dBm]);
rx_gain_dB  = double([minestimates.rx_total_gain_dB]); % gain of the receiver (used below to calculate rx_power)
gps_lat     = [gps_data.latitude];
gps_lon     = [gps_data.longitude];

% calculate distance
dist = calc_dist(gps_lat,gps_lon,'ambialet');
% since frequency of gps_data is 100 less than channel data, we need to
% repeat the distance data 100 times
dist2 = repmat(dist,100,1); 
dist2 = dist2(:);

% extract the time-variant transfer function discarding all frames whithout
% synchronization (UE_mode >=1) 
% also we take only the first OFDM symbol of each frame and the first tx-rx antenna pair
H2 = squeeze(H(:,1,1,UE_mode>=1));

% calculate the total received power by summing over the whole bandwidth 
rx_power    = sum(abs(H2).^2,1);
rx_power_dB = 10*log10(rx_power);

%% account for the automatic gain control 
rx_power_dBm = rx_power_dB - rx_gain_dB(UE_mode>=1);
figure(1)
hold off
plot(rx_power_dBm)

%%
%save rx_power.mat H2 rx_power_dBm
